console.log('Hello World');
console.error('Error');
console.warn('Warn');
// here x is the value of ali age and y is the value of haris age
var aliAge = 10;
var harisAge = 20;

var name = 'ali',
  y = 20,
  weight = 74;

// hoisting
console.log('ali 1: ', ali);
var ali;
console.log('ali 2: ', ali);

ali = 'ali haider';
console.log('ali 3: ', ali);

var js; // declaration
console.log('js: ', js);
js = 'JavaScript'; // assignment
console.log('js: ', js);

//declaration and assignment
// Data types
var name = `Ali Haider`; // string
var _name = 'Ali Haider';
var nAmE = 'Ali Haider123';
var nAmE = '12345';
var nAmE = 'true';
console.log(nAmE);
var nAmE = 60;

var fullName = 'Ali Haider';
console.log('fullName a', fullName);
fullName = 'Hasnain Anwar';
console.log('fullName b', fullName);

var _fullName = fullName;
_fullName = 'Usman';

console.log('_fullName: ', _fullName);

var age = 25; // number
var marks = 90.577; // float
var isAdult = true; // boolean
var _undefined; // boolean
var student = null; // null

var std1 = 'ali';
var std2 = 'haider';
var std3 = 'maaz';
var std4 = 'saif';
var std5 = 'haris';
// primitive data types (value types) vs non-primitive data types (reference types)
console.log(name);
console.log(_name);
console.log(nAmE);
console.log(age, marks, isAdult, _undefined, _null);
// console.log(x, y);
console.log(aliAge, harisAge);
